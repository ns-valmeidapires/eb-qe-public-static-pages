This is a sample ZIP archive.
Created for file download control testing.
Date: 2026-04-19
